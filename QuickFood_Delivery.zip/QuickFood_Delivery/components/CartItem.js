import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SHADOWS } from '../theme';

export default function CartItem({ item, onRemove }) {
  const displayName = [
    item.name,
    item.selectedType ? `(${item.selectedType})` : '',
    item.selectedSpiciness ? `(${item.selectedSpiciness})` : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <View style={styles.item}>
      <View style={styles.itemContent}>
        <View style={styles.leftSection}>
          <Text style={styles.itemName}>{displayName}</Text>
          
          {item.selectedAddOns?.length > 0 && (
            <Text style={styles.addOns}>
              + {item.selectedAddOns.join(', ')}
            </Text>
          )}
        </View>
        
        <View style={styles.rightSection}>
          <Text style={styles.itemPrice}>฿{item.totalPrice}</Text>
          <TouchableOpacity style={styles.removeButton} onPress={onRemove}>
            <Ionicons name="trash-outline" size={16} color={COLORS.white} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    backgroundColor: COLORS.white,
    marginVertical: 6,
    marginHorizontal: 16,
    borderRadius: 10,
    ...SHADOWS.small,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.primary,
  },
  itemContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  leftSection: {
    flex: 1,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemName: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.textDark,
  },
  addOns: {
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 4,
  },
  itemPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginRight: 12,
  },
  removeButton: {
    backgroundColor: COLORS.danger,
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
});