import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Pressable, Image } from 'react-native';
import CartItem from '../components/CartItem';

export default function CartScreen({ route }) {
  const [cart, setCart] = useState([]);
  const [selectedType, setSelectedType] = useState({});
  const [selectedAddOns, setSelectedAddOns] = useState({});
  const [selectedSpiciness, setSelectedSpiciness] = useState({});
  const [showQR, setShowQR] = useState(false);
  const [showCartOnly, setShowCartOnly] = useState(false); // <-- เพิ่ม state นี้
  const restaurant = route?.params?.restaurant || null;

  const toggleAddOn = (itemId, name) =>
    setSelectedAddOns((prev) => ({
      ...prev,
      [itemId]: prev[itemId]?.includes(name)
        ? prev[itemId].filter((n) => n !== name)
        : [...(prev[itemId] || []), name],
    }));

  const addToCart = (item) => {
    const type = selectedType[item.id] || item.types?.[0]?.name || '';
    const addOns = selectedAddOns[item.id] || [];
    const spiciness = item.isSpicy ? selectedSpiciness[item.id] || '' : '';
    const totalPrice =
      item.price +
      (item.types?.find((t) => t.name === type)?.extraPrice || 0) +
      addOns.reduce((sum, name) => sum + (item.addOns?.find((a) => a.name === name)?.extraPrice || 0), 0);

    setCart((prev) => [...prev, { ...item, selectedType: type, selectedAddOns: addOns, selectedSpiciness: spiciness, totalPrice }]);
    setSelectedType((prev) => ({ ...prev, [item.id]: '' }));
    setSelectedAddOns((prev) => ({ ...prev, [item.id]: [] }));
    setSelectedSpiciness((prev) => ({ ...prev, [item.id]: '' }));
  };

  const renderOptions = (item) => (
    <>
      {item.types?.length > 0 && (
        <View style={styles.optionsContainer}>
          <Text style={styles.optionTitle}>เลือกประเภท:</Text>
          <View style={styles.typesContainer}>
            {item.types.map((type) => (
              <TouchableOpacity
                key={type.name}
                style={[styles.typeButton, selectedType[item.id] === type.name && styles.typeButtonSelected]}
                onPress={() => setSelectedType({ ...selectedType, [item.id]: type.name })}
              >
                <Text style={[styles.typeButtonText, selectedType[item.id] === type.name && styles.typeButtonTextSelected]}>
                  {type.name}{type.extraPrice > 0 ? ` (+฿${type.extraPrice})` : ''}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}
      {item.addOns?.length > 0 && (
        <View style={styles.optionsContainer}>
          <Text style={styles.optionTitle}>ตัวเลือกเพิ่มเติม:</Text>
          {item.addOns.map((addOn) => (
            <Pressable key={addOn.name} style={styles.addOnContainer} onPress={() => toggleAddOn(item.id, addOn.name)}>
              <View style={styles.checkbox}>
                {selectedAddOns[item.id]?.includes(addOn.name) && <Text style={styles.checkboxCheck}>✓</Text>}
              </View>
              <Text style={styles.addOnText}>{addOn.name}{addOn.extraPrice > 0 ? ` (+฿${addOn.extraPrice})` : ''}</Text>
            </Pressable>
          ))}
        </View>
      )}
    </>
  );

  return (
    <View style={styles.container}>
      {/* ปุ่มสลับหน้าเมนู ↔ ตะกร้า */}
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginBottom: 10 }}>
        <TouchableOpacity onPress={() => setShowCartOnly(!showCartOnly)}>
          <Text style={{ color: '#1E90FF', fontWeight: 'bold' }}>
            {showCartOnly ? '← กลับไปยังเมนู' : 'ดูตะกร้า →'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* แสดงเมนูเฉพาะเมื่อไม่ได้อยู่ในโหมดตะกร้า */}
      {restaurant && !showCartOnly && (
        <>
          <Text style={styles.title}>{restaurant.name}</Text>
          <FlatList
            data={restaurant.menu}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.menuItem}>
                <Text style={styles.menuItemText}>{item.name} - ฿{item.price}</Text>
                {renderOptions(item)}
                <TouchableOpacity
                  style={styles.addButton}
                  onPress={() => addToCart(item)}
                  disabled={item.types && !selectedType[item.id]}
                >
                  <Text style={styles.addButtonText}>เพิ่ม</Text>
                </TouchableOpacity>
              </View>
            )}
          />
        </>
      )}

      {/* แสดงตะกร้า */}
      <Text style={styles.subtitle}>ตะกร้า:</Text>
      <FlatList
        data={cart}
        keyExtractor={(item, index) => `${item.id}-${index}`}
        renderItem={({ item, index }) => (
          <CartItem item={item} onRemove={() => setCart(cart.filter((_, i) => i !== index))} />
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>ตะกร้าว่างเปล่า</Text>}
      />

      {/* ปุ่มจ่ายเงินแสดงเฉพาะตอนอยู่ในโหมดตะกร้า */}
      {cart.length > 0 && showCartOnly && !showQR && (
        <TouchableOpacity style={styles.payButton} onPress={() => setShowQR(true)}>
          <Text style={styles.payButtonText}>จ่ายเงิน</Text>
        </TouchableOpacity>
      )}

      {/* แสดง QR พร้อมปุ่มปิด */}
      {showQR && (
        <View style={styles.qrContainer}>
          <Image source={require('../assets/qr.png')} style={styles.qrImage} />
          <TouchableOpacity style={styles.closeButton} onPress={() => setShowQR(false)}>
            <Text style={styles.closeButtonText}>ปิด</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}
const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 16,
      backgroundColor: '#fff',
    },
    title: {
      fontSize: 22,
      fontWeight: 'bold',
      marginBottom: 12,
    },
    subtitle: {
      fontSize: 18,
      fontWeight: 'bold',
      marginTop: 16,
      marginBottom: 8,
    },
    menuItem: {
      marginBottom: 20,
      borderBottomWidth: 1,
      borderBottomColor: '#ccc',
      paddingBottom: 10,
    },
    menuItemText: {
      fontSize: 16,
      fontWeight: '500',
    },
    addButton: {
      backgroundColor: '#1E90FF',
      padding: 10,
      marginTop: 10,
      borderRadius: 8,
      alignItems: 'center',
    },
    addButtonText: {
      color: '#fff',
      fontWeight: 'bold',
    },
    emptyText: {
      textAlign: 'center',
      color: '#888',
      marginTop: 20,
    },
    optionsContainer: {
      marginTop: 8,
    },
    optionTitle: {
      fontWeight: 'bold',
      marginBottom: 4,
    },
    typesContainer: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 8,
    },
    typeButton: {
      borderColor: '#ccc',
      borderWidth: 1,
      borderRadius: 6,
      paddingVertical: 4,
      paddingHorizontal: 8,
      marginRight: 8,
      marginBottom: 4,
    },
    typeButtonSelected: {
      backgroundColor: '#1E90FF',
      borderColor: '#1E90FF',
    },
    typeButtonText: {
      color: '#000',
    },
    typeButtonTextSelected: {
      color: '#fff',
    },
    addOnContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 4,
    },
    checkbox: {
      width: 20,
      height: 20,
      borderWidth: 1,
      borderColor: '#1E90FF',
      borderRadius: 4,
      marginRight: 8,
      alignItems: 'center',
      justifyContent: 'center',
    },
    checkboxCheck: {
      color: '#1E90FF',
      fontWeight: 'bold',
    },
    addOnText: {
      fontSize: 14,
    },
    payButton: {
      backgroundColor: '#32CD32',
      padding: 12,
      borderRadius: 10,
      alignItems: 'center',
      marginTop: 10,
    },
    payButtonText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: 'bold',
    },
    qrContainer: {
      alignItems: 'center',
      marginTop: 20,
    },
    qrImage: {
        width: 300,
        height: 350,
        borderRadius: 12, // ขอบมนให้ QR image
      
        
    },
    closeButton: {
      backgroundColor: '#FF6347',
      padding: 10,
      marginTop: 10,
      borderRadius: 8,
    },
    closeButtonText: {
      color: '#fff',
      fontWeight: 'bold',
    },
  });
  