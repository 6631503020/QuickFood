import React from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, ScrollView, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import RestaurantCard from '../components/RestaurantCard';
import { COLORS, SHADOWS } from '../theme';

// ข้อมูลร้านอาหารเหมือนเดิม
const restaurants = [
    {
      id: '1',
      name: 'ร้านอาหารแม่ฟ้า',
      rating: 4.5,
      image: require('../assets/Kapow.png'), // ใช้รูป qr.png
      menu: [
        {
          id: 'm1',
          name: 'ผัดกะเพรา',
          price: 40,
          addOns: [
            { name: 'เพิ่มพิเศษ', extraPrice: 5 },
            { name: 'จัมโบ้', extraPrice: 10 },
          ],
        },
        {
          id: 'm2',
          name: 'ข้าวผัดไข่',
          price: 40,
          addOns: [
            { name: 'เพิ่มพิเศษ', extraPrice: 5 },
            { name: 'จัมโบ้', extraPrice: 10 },
          ],
        },
        {
          id: 'm3',
          name: 'ข้าวผัดพริกเผา',
          price: 55,
          addOns: [
            { name: 'เพิ่มพิเศษ', extraPrice: 5 },
            { name: 'จัมโบ้', extraPrice: 10 },
          ],
        },
      ],
    },
    {
      id: '2',
      name: 'ร้านก๋วยเตี๋ยวลุงลง',
      rating: 4.2,
      image: require('../assets/kt.png'), // ใช้รูป qr.png
      menu: [
        {
          id: 'm1',
          name: 'ก๋วยเตี๋ยวน้ำใส',
          price: 40,
          addOns: [
            { name: 'หมี่เหลือง', extraPrice: 0 },
            { name: 'เส้นเล็ก', extraPrice: 0 },
            { name: 'เส้นใหญ่', extraPrice: 0 },
            { name: 'มาม่า', extraPrice: 0 },
            { name: 'เพิ่มพิเศษ', extraPrice: 5 },
            { name: 'จัมโบ้', extraPrice: 10 },
          ],
        },
        {
          id: 'm2',
          name: 'ก๋วยเตี๋ยวต้มยำ',
          price: 45,
          addOns: [
            { name: 'เผ็ดน้อย', extraPrice: 0 },
            { name: 'เผ็ดมาก', extraPrice: 0 },
            { name: 'เพิ่มพิเศษ', extraPrice: 5 },
            { name: 'จัมโบ้', extraPrice: 10 },
          ],
        },
        {
          id: 'm3',
          name: 'ผัดไทย',
          price: 55,
          addOns: [
            { name: 'เพิ่มพิเศษ', extraPrice: 5 },
            { name: 'จัมโบ้', extraPrice: 10 },
          ],
        },
      ],
    },
  ];
  

// เพิ่มประเภทอาหารเพื่อการกรอง
const categories = [
  "ทั้งหมด", "อาหารตามสั่ง", "ก๋วยเตี๋ยว", "อาหารอีสาน", "อาหารเหนือ", "ร้านข้าว", "ของหวาน", "เครื่องดื่ม"
];


export default function HomeScreen({ navigation }) {
  return (
          <View style={styles.container}>
            
           
      
            {/* ส่วน Search */}
            <View style={styles.searchContainer}>
              <View style={styles.searchBar}>
                <Ionicons name="search" size={20} color={COLORS.textLight} />
                <TextInput
                  style={styles.searchInput}
                  placeholder="ค้นหาร้านอาหาร..."
                  placeholderTextColor={COLORS.textLight}
                />
              </View>
            </View>

      {/* ส่วนเลือกประเภทอาหาร */}
      <View style={styles.categoriesContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesScrollView}
        >
          {categories.map((category, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.categoryBtn,
                index === 0 ? styles.categoryBtnActive : null,
              ]}
            >
              <Text
                style={[
                  styles.categoryText,
                  index === 0 ? styles.categoryTextActive : null,
                ]}
              >
                {category}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* ส่วนหัวข้อ */}
      <View style={styles.headerContainer}>
        <Text style={styles.title}>ร้านอาหารแนะนำ</Text>
        <TouchableOpacity>
          <Text style={styles.viewAll}>ดูทั้งหมด</Text>
        </TouchableOpacity>
      </View>

      

      {/* รายการร้านอาหาร */}
      <FlatList
        data={restaurants}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <RestaurantCard
            restaurant={item}
            onPress={() => navigation.navigate('Cart', { restaurant: item })}
          />
        )}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  
  
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    paddingHorizontal: 12,
    borderRadius: 10,
    height: 44,
    ...SHADOWS.small,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 16,
    color: COLORS.textDark,
  },
  categoriesContainer: {
    paddingVertical: 8,
  },
  categoriesScrollView: {
    paddingHorizontal: 12,
  },
  categoryBtn: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginHorizontal: 4,
    backgroundColor: COLORS.white,
    ...SHADOWS.small,
  },
  categoryBtnActive: {
    backgroundColor: COLORS.primary,
  },
  categoryText: {
    fontSize: 14,
    color: COLORS.textDark,
  },
  categoryTextActive: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textDark,
  },
  viewAll: {
    fontSize: 14,
    color: COLORS.primary,
    fontWeight: '500',
  },
});