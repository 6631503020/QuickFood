// theme.js
export const COLORS = {
    primary: '#1E88E5',       // สีฟ้าหลัก
    primaryDark: '#0D47A1',   // สีฟ้าเข้ม
    primaryLight: '#64B5F6',  // สีฟ้าอ่อน
    accent: '#29B6F6',        // สีฟ้าเน้น
    background: '#F5FAFF',    // พื้นหลังสีฟ้าอ่อนมาก
    white: '#FFFFFF',
    textDark: '#263238',
    textLight: '#546E7A',
    danger: '#E53935',        // สีแดง (สำหรับปุ่มลบ)
    success: '#43A047',       // สีเขียว (สำหรับปุ่มยืนยัน)
    border: '#BBDEFB',        // สีขอบ
    shadow: 'rgba(30, 136, 229, 0.2)', // สีเงา
    cardBg: '#FFFFFF',        // พื้นหลังการ์ด
  };
  
  export const SHADOWS = {
    small: {
      shadowColor: COLORS.shadow,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 2,
    },
    medium: {
      shadowColor: COLORS.shadow,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.3,
      shadowRadius: 4.65,
      elevation: 4,
    },
    large: {
      shadowColor: COLORS.shadow,
      shadowOffset: { width: 0, height: 6 },
      shadowOpacity: 0.37,
      shadowRadius: 7.49,
      elevation: 6,
    },
  };